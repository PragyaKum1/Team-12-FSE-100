let pencilImage;
let paperImage;
let checkmarkImage;
let blocksImage;
let questionImage;
let xImage;
let selectTrace;
let selectNoTrace;
let writingStart;
let writingDone;
let writingBack;
let writingNext;
let wordList;
let simpleSentences;
let bellSound;
let buzzerSound;
var writingMode = 0;
var wordsGameLevel = 0;
var sentencesGameLevel = 0;
var lettersGameLevel = 0;
var complexSentencesGameLevel = 0;
let levelDone = true;

function preload() {
  pencilImage = loadImage('trasnparentpencil.png');
  paperImage = loadImage('papernotebook2.png');
  checkmarkImage = loadImage('greenCheckmark.png');
  xImage = loadImage('redX.png');
  quillImage = loadImage('quillpen.png')
  blocksImage = loadImage('blocks.png')
  questionImage = loadImage('transparentquestionmark.png')
  wordList = loadStrings('wordlist.10000.txt')
  simpleSentences = loadStrings('simpleSentences.txt')
  letterList = loadStrings('letters.txt')
  soundFormats('wav');
  bellSound = loadSound('bellSound.wav');
  buzzerSound = loadSound('buzzerSound.wav')
}
  
function setup() {
  createCanvas(600, 600)
  background(100,200,300);
  fill('white')
  rect(0,0,600,40)
  textSize(24)
  circle(425,20,30);
  fill('black')
  text('username',450,27)
}

function setupHomeButtons() {
  Home = createButton("Home");
  Home.position(10,10);
  Home.mousePressed(GoHome);
  
  writingMenu = createButton('Main Menu')
  writingMenu.position(75, 10)
  writingMenu.mousePressed(selectMainMenu)
  
   function selectMainMenu() {
    writingMode = 0;
    loop();
  }
  
  function GoHome(){
    window.open('https://editor.p5js.org/PragyaKumari2/sketches/3fhigQjLg');
  }
  if (!writingDone) {
  writingDone = createButton("Done");
  writingDone.position(175, 10);
  }
  writingDone.mousePressed(negativeFeedback);
  if (!writingBack) {
    writingBack = createButton("Back");
    writingBack.position(350, 525)
    writingBack.size(100,40)
  }
  writingBack.mousePressed(backLevel);
  if (!writingNext) {
    writingNext = createButton("Next");
    writingNext.position(475, 525)
    writingNext.size(100,40)
  }
  writingNext.mousePressed(nextLevel);
  if (levelDone) {
    loop();
  }
  if (!levelDone) {
    noLoop();
  }
}


function draw() {
  if (writingMode == 0) {
    strokeWeight(1)
    writingMainMenu();
    levelDone = true;
    loop()
  } 
  else if (writingMode == 1) {
    simpleSentencesStart();
    //selectNoTrace.hide();
    writingStart.show();
  }
  else if (writingMode == 2) {
    //noLoop();
    simpleSentencesWritingMode();
    writingStart.hide();
    writingBack.show();
    writingNext.show();
    writingDone.show();
  }
  else if (writingMode == 3) {
    writingBack.show();
    writingNext.show();
    writingDone.show();
    levelDone = false;
    simpleWordsWritingMode();
  }
  else if (writingMode == 4) {
    writingBack.show();
    writingNext.show();
    levelDone = false;
    lettersWritingMode();
  }
  else if (writingMode == 5) {
    complexSentencesWritingMode();
  }
  if (writingMode == 2) {
    writingStart.hide();
  }
  if (writingMode == 0 && writingBack && writingNext) {
    writingNext.hide();
    writingBack.hide();
  }
  if (writingMode == 0 && writingDone) {
    writingDone.hide();
  }
  setupHomeButtons();
}

function mouseDragged() {
  fill('green') 
  //stroke('green')
  ellipse(mouseX, mouseY,10,10);
}

function writingMainMenu() {
  background(100,200,300);
  fill('white')
  rect(0,0,600,40)
  textSize(24)
  circle(425,20,30);
  fill('black')
  text('username',450,27)
  fill('black')
  text('Select Your Game Mode...', 150, 100)
  fill('white')
  rect(25, 150, 250, 150, 15)
  rect(325, 150, 250, 150, 15)
  rect(25, 350, 250, 150, 15)
  rect(325, 350, 250, 150, 15)
  image(blocksImage, 25, 175, 100, 100)
  image(pencilImage, 330, 175, 100, 100)
  image(paperImage, 10, 375, 135, 100)
  image(quillImage, 330, 365, 100, 100)
  fill('black')
  textSize(40)
  textFont('Comic Sans MS')
  text('Letters', 125, 230)
  text('Words', 430, 230)
  textSize(32)
  textWrap(WORD)
  text('Simple Sentences', 115, 385, 50)
  text('Complex Sentences', 415, 385, 50)
  
  if (mouseX > 25 && mouseX < 25 + 250) {
    if (mouseY > 150 && mouseY < 150 + 150) {
      if (mouseIsPressed) {
        writingMode = 4;
      }
    }
  }
  
  if (mouseX > 325 && mouseX < 325 + 250) {
    if (mouseY > 150 && mouseY < 150 + 150) {
      if (mouseIsPressed) {
        writingMode = 3;
      }
    }
  }
  if (mouseX > 25 && mouseX < 25 + 250) {
    if (mouseY > 375 && mouseY < 375 + 150) {
      if (mouseIsPressed) {
        selectNoTraceMode();
      }
    }
  }
  if (mouseX > 325 && mouseX < 325 + 250) {
    if (mouseY > 375 && mouseY < 375 + 150) {
      if (mouseIsPressed) {
        writingMode = 5;
      }
    }
  }
  fill('lightgray')
  ellipse(60, 550, 60, 60)
  image(questionImage, 35, 525, 50, 50)
  if (dist(mouseX, mouseY, 60, 550) < 60) {
    if (mouseIsPressed) {
      helpScreen();
    }
  }
}


function selectNoTraceMode() {
    writingMode = 1;
  }

function simpleSentencesStart() {
  background(100,200,300);
  fill('white')
  rect(0,0,600,40)
  textSize(24)
  circle(425,20,30);
  fill('black')
  text('username',450,27)
  if (!writingStart) {
  writingStart = createButton("Start");
  writingStart.position(175, 10);
  }
  //fill('white')
  //rect(242,5,150,30)
  fill('black')
  //text('Timer: 00:57',250,27)
  text('Copy the given prompt in the lines below', 75, 100)
  text('Press "Start" to begin writing!',125,175)
  
  rect(20,250,550,2)
  rect(20,310,550,2)
  rect(20,370,550,2)
  rect(20,430,550,2)
  rect(20,490,550,2)
  
writingStart.mousePressed(selectWritingGame);
}
function selectWritingGame() {
  writingMode = 2;
  levelDone = false;
}

function simpleSentencesWritingMode() {
  background(100,200,300);
  fill('white')
  rect(0,0,600,40)
  textSize(24)
  circle(425,20,30);
  fill('black')
  text('username',450,27)
  text('Level: ' + (sentencesGameLevel + 1), 300, 27);
  
  text(simpleSentences[sentencesGameLevel], 100, 100, 500, 500);
  
  rect(20,250,550,2)
  rect(20,310,550,2)
  rect(20,370,550,2)
  rect(20,430,550,2)
  rect(20,490,550,2)
  
}

function simpleWordsWritingMode() {
  background(100,200,300);
  fill('white')
  rect(0,0,600,40)
  textSize(24)
  circle(425,20,30);
  fill('black')
  text('username',450,27)
  text('Level: ' + (wordsGameLevel + 1), 300, 27);
  textSize(100)
  text(wordList[wordsGameLevel], 100, 100, 100)

}

function lettersWritingMode() {
  background(100,200,300);
  fill('white')
  rect(0,0,600,40)
  textSize(24)
  circle(425,20,30);
  fill('black')
  text('username',450,27)
  text('Level: ' + (lettersGameLevel + 1), 300, 27);
  textSize(100)
  text(letterList[lettersGameLevel], 100, 100, 100)
}

function complexSentencesWritingMode() {
  background(100,200,300);
  fill('white')
  rect(0,0,600,40)
  textSize(24)
  circle(425,20,30);
  fill('black')
  text('username',450,27)
}

function nextLevel() {
  if (writingMode == 2) {
    sentencesGameLevel += 1;
  }
  if (writingMode == 3) {
    wordsGameLevel += 1;
  }
  if (writingMode == 4) {
    lettersGameLevel += 1;
  }
  loop();
}
function backLevel() {
  if (writingMode == 2) {
    sentencesGameLevel -= 1;
  }
  if (writingMode == 3) {
    wordsGameLevel -= 1;
  }
  if (writingMode == 4) {
    lettersGameLevel -= 1;
  }
  loop();
}


function positiveFeedback() {
  bellSound.play();
  image(checkmarkImage, 350, 100, 200, 200);
}

function negativeFeedback() {
  buzzerSound.play();
  image(xImage, 350, 100, 200, 200);
}
  
function helpScreen() {
  noLoop();
  fill('white')
  strokeWeight(5)
  rect(25, 300, 250, 290)
  textSize(20)
  textWrap(WORD)
  fill('black')
  text('- Select one of four game modes!', 40, 315, 240)
  text('- Click and drag your cursor to write on the screen.', 40, 375, 240)
  text('- Trace the outlines of the prompts given.', 40, 460, 240)
}