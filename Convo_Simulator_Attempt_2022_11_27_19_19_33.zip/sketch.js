let img
let img2
let img3
let img4
let img5
let img6



function preload(){
  img = loadImage("BARBQ1.png");
  img2 = loadImage("BARBQ2.png");
  img3 = loadImage("BARBQ3.png");
  img4 =loadImage("BARBQ4.png");
  img5 = loadImage("BARBfinal.png");
  img6 = loadImage("BARBend.png");
}
  


function setup() {
  background(100,200,300)
  createCanvas(1500,1000);
  scene = 1; 
  
  ButtonA = createButton("A. GOOD");
  ButtonA.position(20,560);
  ButtonA.size(100,50)
  ButtonA.mouseClicked(correct0);
          
 
  

  ButtonB = createButton("B. PINEAPPLE");
  ButtonB.position(20,620);
  ButtonB.size(100,50)
  ButtonB.mouseClicked(incorrect0);
  
 
  ButtonC = createButton("C. PLEASE KILL ME");
  ButtonC.position(20,680);
  ButtonC.size(100,50)
  ButtonC.mouseClicked(incorrect1);
  
  

  ButtonD = createButton("A. Good!");
  ButtonD.position(20,560);
  ButtonD.size(100,50)
  ButtonD.mouseClicked(incorrect2);
  ButtonD.hide(); 
  

  ButtonE = createButton("B. PINEAPPLE");
  ButtonE.position(20,620);
  ButtonE.size(100,50)
  ButtonE.mouseClicked(correct1);
  ButtonE.hide(); 
  
 
  ButtonF = createButton("C. PLEASE KILL ME");
  ButtonF.position(20,680);
  ButtonF.size(100,50)
  ButtonF.mouseClicked(incorrect3);
  ButtonF.hide(); 
  
   ButtonG = createButton("1. Delicious");
  ButtonG.position(20,560);
  ButtonG.size(100,50)
   ButtonG.mouseClicked(incorrect4);
  ButtonG.hide(); 
 
  

  ButtonH = createButton("2. Rainy");
  ButtonH.position(20,620);
  ButtonH.size(100,50)
  ButtonH.mouseClicked(correct2);
  ButtonH.hide(); 
  
 
  ButtonI = createButton("3. Red!");
  ButtonI.position(20,680);
  ButtonI.size(100,50)
  ButtonI.mouseClicked(incorrect5);
  ButtonI.hide(); 
  
   ButtonJ = createButton("1. My name is __!");
  ButtonJ.position(20,560);
  ButtonJ.size(100,50)
   ButtonJ.mouseClicked(correct3);
  ButtonJ.hide(); 
  
 
  

  ButtonK = createButton("2. Yes.");
  ButtonK.position(20,620);
  ButtonK.size(100,50)
   ButtonK.mouseClicked(incorrect6);
  ButtonK.hide(); 
  
 
  ButtonL = createButton("3. Carpe Diem!");
  ButtonL.position(20,680);
  ButtonL.size(100,50)
   ButtonL.mouseClicked(incorrect7);
  ButtonL.hide(); 
  
  
  ButtonM = createButton("1. Hello, Barb!");
  ButtonM.position(20,560);
  ButtonM.size(100,50)
   ButtonM.mouseClicked(incorrect8);
  ButtonM.hide(); 
  
   ButtonN = createButton("2. Goodbye, Barb!");
  ButtonN.position(20,620);
  ButtonN.size(100,50)
   ButtonN.mouseClicked(correct4);
  ButtonN.hide(); 
  
   ButtonO = createButton("3. OH FINALLY IT'S OVER!");
  ButtonO.position(20,680);
  ButtonO.size(100,50)
   ButtonO.mouseClicked(incorrect9);
  ButtonO.hide(); 
  
   homebutton = createButton("HOME");
  homebutton.position(420, 560);
  homebutton.size(200, 40);
  homebutton.mousePressed(goHome);
  homebutton.hide();
  
  
}
  function correct0(){
  text("You answered the first question right! Hold left click and '2' to advance!'",280, 630)
   }

function correct1(){
  text("You answered this question right! Hold left click and '3' to advance'", 280, 650);
}
function correct2(){
  text("That's right! Hold left click and '4' to advance'", 280, 670);
}
function correct3(){
  text("'Good job!' Hold left click and '5' to advance'", 280, 690);
}
function correct4(){
  text("Well done! Hold left click and '6' to advance'", 280, 710);
}

function incorrect0(){
  text("Pineapple is not an emotion, please try again.", 280, 730);
}
function incorrect1(){
  text("Please seek therapy and try again.", 280, 750);
}
function incorrect2(){
  text("Good is not a food, please try again", 280, 770);
}
function incorrect3(){
  text("Your life has just begun...please try again.", 280, 790);
}
function incorrect4(){
  text("Delicious is not a type of weather, try again.", 280, 810);
}
function incorrect5(){
  text("Please move planets before trying again.", 280, 830);
}
function incorrect6(){
  text("Yes is no. Try again.", 280, 850);
}
function incorrect7(){
  text("Seize the moment, indeed. But try again!",280,870);
}
function incorrect8(){
  text("This is a time for goodbyes, friend, try again.", 280, 890);
}
function incorrect9(){
  text(" : ( why don't you try again?", 280, 910);
}

function goHome(){
    window.open('https://editor.p5js.org/PragyaKumari2/sketches/3fhigQjLg');  
  }

function draw() {
  
          if(scene ==1){
            image(img,0,0,800,600)
  textSize(19);
              if(keyIsPressed){
                if(key ==2){
                  scene =2
                  ButtonA.remove();
                  ButtonB.remove();
                  ButtonC.remove();
                  ButtonD.show();
                   ButtonE.show();
                   ButtonF.show();
                  
                  
          }
             
        }
    }


  
  if(scene ==2){
  image(img2,0,0,800,600)
  textSize(20);
  

  
      if(keyIsPressed){
                if(key ==3){
                  scene =3
                  ButtonD.remove();
                  ButtonE.remove();
                  ButtonF.remove();
                  ButtonG.show();
                  ButtonH.show();
                  ButtonI.show();
          }
             
        }
 
  }
  if(scene == 3){
  image(img3,0,0,800,600)
  textSize(20);

  
      if(keyIsPressed){
                if(key ==4){
                  scene =4
                  ButtonG.remove();
                  ButtonH.remove();
                  ButtonI.remove();
                ButtonJ.show();
                  ButtonK.show();
                  ButtonL.show();
          }
             
        }
    
  }
 if(scene ==4){
   image(img4,0,0,800,600)
  
      if(keyIsPressed){
                if(key ==5){
                  scene =5
                  ButtonJ.remove();
                  ButtonK.remove();
                  ButtonL.remove();
                  ButtonM.show();
                  ButtonN.show();
                  ButtonO.show();
                }
             
        }
   
 }
  if(scene == 5){
    image(img5, 0,0, 800,600)
   
      if(keyIsPressed){
                if(key ==6){
                  scene =6
                  image(img6, 0, 0, 800, 600);
                  ButtonM.remove();
                  ButtonN.remove();
                  ButtonO.remove();
                  homebutton.show();
                }             
  }
  }
  
  if(scene == 6){
       image(img6, 0,0, 800,600)
        homebutton.show();
        text("Click Home to play another game!", 280, 930);
        
     
    
  }
   
 rect(420, 560, 200,40)
 text("BARB's Responses: ", 440, 580);
 

}
 

  
    
    
            


  
  
