function setup() {
  createCanvas(600, 600);
}

function draw() {
  background(220);
  background(100,200,300);
  
  rect(0,0,600,40)
  textSize(24)
  text('username',450,27)
  circle(425,20,30);
  
text("Welcome to Shape Match!", 160, 85)
  
   text("•Drag a shape from the shape bank to its outline", 60, 160)
  text("•Each correct match awards you with one point", 60, 250)
 text("•Each wrong answer gives you no points", 60, 350)
  
  
  Home = createButton("Home");
  Home.position(10,10);
  Home.mousePressed(GoHome);
  
    Game1 = createButton("Start!");
  Game1.position(275,450);
  Game1.size(50,30)
  Game1.mousePressed(GoToShapeMatch);
 
    
  
  function GoHome(){
    window.open('https://editor.p5js.org/PragyaKumari2/sketches/3fhigQjLg');
  } 
  function GoToShapeMatch(){
    window.open('https://editor.p5js.org/lhgonza1/sketches/0eq8-8nuq');
  }
}